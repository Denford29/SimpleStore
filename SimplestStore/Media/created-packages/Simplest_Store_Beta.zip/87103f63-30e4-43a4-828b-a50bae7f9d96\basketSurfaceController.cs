﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SimplestStore.Models;
using Umbraco.Core.Models;
using Umbraco.Web.Mvc;

namespace SimplestStore.Controllers
{

    public class basketSurfaceController : SurfaceController
    {
        
        //
        // GET: /basketSurface/
        [ChildActionOnly]
        public ActionResult Index()
        {
            return PartialView("addToBasket", CurrentPage);
        }

        [HttpPost]
        public ActionResult SiteWideAddToBasket(int productPageId)
            {

            if (!ModelState.IsValid)
                return CurrentUmbracoPage();

            //set a flag we gona update with the results of adding to the basket and create the var's we need in the logic
            var addedToCart = false;
            var currentBasket = new basketItem();

            var productPage = Umbraco.TypedContent(productPageId);
            if (productPage != null)
                {
                var productPrice = productPage.GetProperty("productPrice").Value.ToString();
                if (!string.IsNullOrEmpty(productPrice))
                    {
                    var productPriceValue = Convert.ToDecimal(productPrice);
                    addedToCart = currentBasket.GetCart().AddProduct(productPage, 1, productPriceValue);
                    }
                else
                    {
                    addedToCart = currentBasket.GetCart().AddProduct(productPage, 1, 1);
                    }

                // create some temp data to use to show if the product has been added successfully or not
                if (addedToCart)
                    {
                    TempData["success"] = true;
                    }
                else
                    {
                    TempData["failure"] = true;
                    }

                return RedirectToCurrentUmbracoPage();
                }
            else
                {
                TempData["failure"] = true;
                return CurrentUmbracoPage();
                }
            }

        [HttpPost]
        public ActionResult ProductPageAddToBasket()
        {
            if (!ModelState.IsValid)
                return CurrentUmbracoPage();

            //set a flag we gona update with the results of adding to the basket and create the var's we need in the logic
            var addedToCart = false;
            var currentBasket = new basketItem();

            var productPrice = CurrentPage.GetProperty("productPrice").Value.ToString();
            if (!string.IsNullOrEmpty(productPrice))
            {
                var productPriceValue = Convert.ToDecimal(productPrice);
                addedToCart = currentBasket.GetCart().AddProduct(CurrentPage, 1, productPriceValue);
            }
            else
            {
            addedToCart = currentBasket.GetCart().AddProduct(CurrentPage, 1, 1);
            }

            // create some temp data to use to show if the product has been added successfully or not
            if (addedToCart)
                {
                TempData["success"] = true;
                }
            else
                {
                TempData["failure"] = true;
                }

            return RedirectToCurrentUmbracoPage();
        }

        [HttpPost]
        public ActionResult ExtraProductAddToBasket(int extraProductPageId, int mainProductPageId)
            {
            if (!ModelState.IsValid)
                return CurrentUmbracoPage();

            //set a flag we gona update with the results of adding to the basket and create the var's we need in the logic
            var addedToCart = false;
            var currentBasket = new basketItem();
            var extraMainPage = Umbraco.TypedContent(mainProductPageId);
            if (extraMainPage != null && extraMainPage.Id > 0 && extraMainPage.GetProperty("productPrice").HasValue)
                {
                var productPrice = extraMainPage.GetProperty("productPrice").Value.ToString();
                var extraProductPage = Umbraco.TypedContent(extraProductPageId);
                if (extraProductPage != null && !string.IsNullOrEmpty(productPrice))
                    {
                    var productPriceValue = Convert.ToDecimal(productPrice);
                    addedToCart = currentBasket.GetCart().AddExtraProduct(extraMainPage, productPriceValue, extraProductPage, 1);
                    }
                }
            else
                {
                TempData["failure"] = true;
                }

            // create some temp data to use to show if the product has been added successfully or not
            if (addedToCart)
                {
                TempData["success"] = true;
                }
            else
                {
                TempData["failure"] = true;
                }

            return RedirectToCurrentUmbracoPage();
            }


        [HttpPost]
        public ActionResult RemoveFromBasket(int productPageId)
        {
            if (!ModelState.IsValid)
                return CurrentUmbracoPage();

            var currentBasket = new basketItem();

            var productPage = Umbraco.TypedContent(productPageId);
            if (productPage != null)
            {
            currentBasket.GetCart().RemoveLine(productPage);
            }

            TempData["success"] = true;

            return RedirectToCurrentUmbracoPage();
        }

        [HttpPost]
        public ActionResult EmptyBasket()
            {
            var currentBasket = new basketItem();
            currentBasket.GetCart().Clear();
            return RedirectToCurrentUmbracoPage();
            }
    }
}
